﻿ //退出浏览器时，自动清理垃圾
chrome.storage.local.clear();
