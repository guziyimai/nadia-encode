﻿var updateStr="",newVersion=false;
//返回更新结果
function updateHTML(){
	return updateStr;
}
function checkNew(){
	if(newVersion){
		chrome.browserAction.setBadgeBackgroundColor({"color":"#0F0"});
		chrome.browserAction.setBadgeText({"text":"new"});
	} else {
		chrome.browserAction.setBadgeText({"text":""});
	}
}
var nadia_background=function(){
//是否为首次安装
var version="1.4.3",runCrx=1;
var updateDiv=document.getElementById("update");
updateDiv.setAttribute("version",version);
try{
chrome.storage.local.get("version",function(res){
	if(!res["version"]||res["version"]!=version) {
		if(!res["version"]){
			chrome.storage.local.set({"runCrx":"1"});
			chrome.storage.local.set({"keyBinds":"112,113"});
		}
		chrome.storage.local.set({"version":version});
		window.open("https://share.mockplus.cn/go/nadia/update.html","_blank");
	}
});
}catch(e){}
//检测开关状态
try{
chrome.storage.local.get("runCrx",function(res){
	if(res["runCrx"]=="-1") {
		runCrx=-1;
		chrome.browserAction.setBadgeText({"text":"×"});
		chrome.browserAction.setBadgeBackgroundColor({"color":"#F00"});
	}
});
}catch(e){}

//检测更新
var updatejs;
var updateArr=[
"https://share.mockplus.cn/go/nadia/",
"https://nadia-jiami.netlify.app/",
"https://nadia-encode.neocities.org/"
];
chrome.storage.local.set({"MainJS":updateArr[0]});

//获取更新信息
var timerNum=0,timerId,tryArr=0,maxWait=6;
function cleanUpdate(){
	clearInterval(timerId);
	updatejs.remove();
	updateDiv.remove();
	chrome.storage.local.set({"MainJS":updateArr[tryArr]});
	setTimeout(function(){
		if(updateStr.length>60) newVersion=true;
		if(runCrx==1) checkNew();
	},50);
}

//轮询测试3个线路是否宕机
testUpdate1();
function testUpdate1(){
	updatejs=document.createElement("script");
	updatejs.src=updateArr[tryArr]+"update.js";
	document.body.appendChild(updatejs);
	timerId=setInterval(testUpdate2,200);
}

function testUpdate2(){
	timerNum++;
	updateStr=updateDiv.innerHTML;
	if(updateStr) {
		cleanUpdate();
	}else if(timerNum>maxWait){
		//3秒如果还没取到更新结果，则网速太慢——是否VPN更改导致的407？
		clearInterval(timerId);
		updatejs.remove();
		if(tryArr<3){tryArr++;}else{tryArr=0;}
		if(maxWait<40) maxWait+=10;
		testUpdate1();
	}
}

//清除JS痕迹
document.getElementsByTagName("script")[0].remove();
return "guziyimai "+version;
}();
