﻿var nadia_mainfast=function(){
//兽音定时参数
var timerNum,timerId,ipt,rsIpt,notDelay,btn,maxWait,isDiv,errStr="\n【纳迪亚解密插件】调用失败，请尝试手动解密，如果不能解密，则是源密文有误；\n如果手动解密成功，请反馈此BUG：3625270272@qq.com";
/**
 * 获取元素
 * @author guziyimai
 */
function getObj(id,type){
	if(type==1){
		return document.getElementsByTagName(id);
	} else if(type==2){
		return document.getElementsByClassName(id);
	} else {
		return document.getElementById(id);
	}
}

//定义变量
var isPowerUrl=false;
var version="1.4.4";
var NadiaTQM=document.createElement("NadiaTQM");
var mainjs=document.createElement("script");
var runCrx="2",keyBinds="-1";

try{
	isPowerUrl=getObj("Z3V6aXlpbWFp",2).length==5;
	//向官网注入NadiaCrx标记，而不是JS
	if(isPowerUrl){
		//需要注入
		var NadiaCrx=getObj('NadiaCrx',1);
		if(NadiaCrx && NadiaCrx[0]) {
			NadiaCrx[0].innerHTML="KnXNNnV3wp";
		}
		var NadiaVer=getObj('nadia_decode');
		if(NadiaVer){
			NadiaVer.innerHTML="纳迪亚文本解密"+version;
			NadiaVer.parentElement.title="版本号："+version;
			return "guziyimai "+version;
		}
		return "guziyimai "+version;
	}
}catch(e){}

//从storage取版本号的值
document.body.appendChild(NadiaTQM);
chrome.storage.local.get("version",function(res){
	try{version=res["version"];}catch(e){}
	//注入提取码存储元素
	NadiaTQM.setAttribute("version",version);
	//注入主JS
	chrome.storage.local.get("MainJS",function(res){
		try{
			mainjs.src=res["MainJS"];
		}catch(e){
			mainjs.src="https://share.mockplus.cn/go/nadia/";
		}
		mainjs.src+="NadiaCrx.js";
		mainjs.id="NadiaCrx_guziyimai";
		document.body.appendChild(mainjs);
	});
});

//自动粘贴，不向百度云注入JS
//替换为：调用百度秒传脚本
var runUrl=top.location.href;
if('pan.baidu.com'==runUrl.substr(8,13)){
	if('/disk/main'==runUrl.substr(21,10)){
		try{
			key='baidumiaochuan';
			chrome.storage.local.get(key,function(res){
				if(res[key]) {
					//console.log("调用秒传："+res[key]);
					timerNum=0;
					chrome.storage.local.remove("baidumiaochuan");
					timerId=setInterval(function(){
						timerNum++;
						if(getObj("bdlink_btn")) {
							clearInterval(timerId);
							getObj("bdlink_btn").click();
							timerNum=0;
							timerId=setInterval(function(){
								timerNum++;
								if(getObj('mzf-rapid-input')){
									getObj('mzf-rapid-input').value=res[key];
									clearInterval(timerId);
								} else if(timerNum>3){
									clearInterval(timerId);
								}
							},99);
						} else if(timerNum>3){
							clearInterval(timerId);
							alert("请安装秒传插件：https://greasyfork.org/zh-CN/scripts/424574");
							window.location.href="https://nadia-jiami.netlify.app/idm.html";
						}
					},99);
				}
			});
		} catch(e) {}
	}
	return "guziyimai "+version;
}

//判断是否为兽音/佛曰
if(
	'www.qqxiuzi.cn'==runUrl.substr(8,14)
	|| 'www.keyfc.net'==runUrl.substr(8,13)
	|| 'hi.pcmoe.net'==runUrl.substr(7,12)
	|| 'www.sojson.com/encrypt_aes'==runUrl.substr(8,26)
){
	var key=runUrl.match(/http.{15,40}(html|aspx|php|morse)/);
	//console.log(key);
	notDelay=false;maxWait=18;
	try{
		if(runUrl.indexOf("hi.pcmoe.net")!=-1){
			ipt=getObj("pw");
			rsIpt=getObj("bear");
			btn=getObj("moeBtn",2)[1];
		} else if(runUrl.indexOf("www.sojson.com/encrypt_aes")!=-1) {
			//console.log("sojsonAES");
			notDelay=true;
			ipt=getObj("result");
			rsIpt=getObj("source");
			btn=getObj("layui-btn",2)[1];
		} else if(runUrl.indexOf("www.keyfc.net/bbs/tools/tudoucode.aspx")!=-1){
			notDelay=true;
			ipt=getObj("afterMsg");
			rsIpt=getObj("orignalMsg");
			btn=getObj("tudouDecode");
		} else if(runUrl.indexOf("www.qqxiuzi.cn/bianma/wenbenjiami.php")!=-1){
			///notDelay=true;
			ipt=getObj("text");
			rsIpt=getObj("show");
			btn=getObj("input",1)[1];
		}
	}catch(e){}
	if(!key||!btn) return "guziyimai "+version;
	try{
		key=key[0];
		chrome.storage.local.get(key,function(res){
			if(res[key]) {
				maxWait+=parseInt(res[key].length/800);
				setTimeout(function(){ipt.value=res[key];},50);
				timerNum=0;
				timerId=setInterval(function(){
					timerNum++;
					if(notDelay || btn.getAttribute("onclick")){
						chrome.storage.local.remove(key);
						//兽音坑爹的延迟绑定！
						clearInterval(timerId);
						var tqm;
						timerNum=0;
						btn.click();
						timerId=setInterval(function(){
							timerNum++;
							tqm=rsIpt.value;
							if(tqm||timerNum>4) {
								clearInterval(timerId);
								timerNum=0;
								timerId=setInterval(function(){
									timerNum++;
									tqm=rsIpt.value;
									if(tqm||timerNum>=maxWait) {
										clearInterval(timerId);
										if(timerNum<maxWait && !/异常|太深奥|解码失败/.test(tqm)){
											chrome.storage.local.set({"return-roar":tqm},function(){top.close();});
										} else {
											rsIpt.value=rsIpt.value+errStr;
										}
									}
								},150);
							} else {
								btn.click();
							}
						},180);
					} else if(timerNum>10){
						clearInterval(timerId);
						rsIpt.value=rsIpt.value+errStr;
					}
				},150);
			}
		});
	} catch(e) {}
	return "guziyimai "+version;
}

//获取运行开关
function getSet(){
	try{
		//是否运行
		chrome.storage.local.get("runCrx",function(res){
			try{
				if(res["runCrx"]&&runCrx!=res["runCrx"]){
					runCrx=res["runCrx"];
					NadiaTQM.setAttribute("runCrx",runCrx);
					if(runCrx=="1") {
						console.log("启用：纳迪亚解密"+version);
					} else {
						console.log("停用：纳迪亚解密"+version);
					}
					document.getSelection().empty();
					getObj("nadia_menu").style.display="none";
					getObj("kill_tieba_ad",2)[0].click();
				}
			}catch(e){}
		});
		//绑定按键
		chrome.storage.local.get("keyBinds",function(res){
			try{
				if(res["keyBinds"]&&keyBinds!=res["keyBinds"]){
					keyBinds=res["keyBinds"];
					NadiaTQM.setAttribute("keyBinds",keyBinds);
					document.getSelection().empty();
					getObj("nadia_menu").style.display="none";
				}
			}catch(e){}	
		});
	}catch(e){}
}
try{getSet();chrome.storage.onChanged.addListener(getSet);}catch(e){}
NadiaTQM.onclick=function(e){
	var key=NadiaTQM.getAttribute("key");
	var obj={};obj[key]=NadiaTQM.getAttribute("tqm");
	try{
		chrome.storage.local.set(obj,function(){
			NadiaTQM.removeAttribute("key");
			NadiaTQM.removeAttribute("tqm");
			//是否为兽音传参？
			if(key&&key.substr(0,4)=="http"){
				timerNum=0;
				timerId=setInterval(function(){
					timerNum++;
					try{
						chrome.storage.local.get("return-roar",function(res){
							if(res["return-roar"]) {
								clearInterval(timerId);
								chrome.storage.local.remove("return-roar");
								NadiaTQM.setAttribute("return-roar",res["return-roar"]);
							} else if(timerNum>60){
								clearInterval(timerId);
							}
						});
					} catch(e) {}
				},150);
			}
		});
	}catch(e){}
	e.stopPropagation();
}

setTimeout(function(){
	try{
		var str=getObj("NadiaCrx_guziyimai").getAttribute("data");
		if(isPowerUrl||str=="jsIsRun"){
			//自毁代码
			setTimeout(function(){mainjs.remove();},200);
		}else{
			//服务器已宕机，15秒后重新切换服务器
			chrome.storage.local.set({"CheckAgain":true});
			mainjs.remove();
			if(mainjs.src.indexOf("mockplus")!=-1){
				mainjs.src="https://nadia-jiami.netlify.app";
			}else{
				mainjs.src="https://share.mockplus.cn/go/nadia";
			}
			mainjs.src+="/NadiaCrx.js";
			document.body.appendChild(mainjs);
			setTimeout(function(){mainjs.remove();},1700);
		}
	}catch(e){}
},1500);

/**
 * 给SB的IE用的！！！
 * @author guziyimai
 */
try{
	"".replaceAll("");
}catch(err){
	String.prototype.replaceAll=function(a,b){
		return this.split(a).join(b);
	};
	Array.prototype.indexOf=function(elt,start){
		var len=this.length;
		if(!start) start=0;
		for(;start<len;start++)
			if(this[start] == elt) return start;
		return -1;
	};
}

return "guziyimai "+version;
}();