﻿var updateStr="",newVersion=false,isRun=true;
//返回更新结果
function updateHTML(){
	return updateStr;
}
//检测版本更新
function checkNew(){
	if(newVersion){
		chrome.browserAction.setBadgeBackgroundColor({"color":"#0F0"});
		chrome.browserAction.setBadgeText({"text":"new"});
	} else {
		chrome.browserAction.setBadgeText({"text":""});
	}
}
var nadia_background=function(){
//版本检测
var version="1.4.5",runCrx=1;
var updateDiv=document.getElementById("update");
updateDiv.setAttribute("version",version);
//检测更新
var updatejs;
//3个线路的优先级，其中mockplus是主线路
var updateArr=[
"https://share.mockplus.cn/go/nadia/",
"https://guziyimai.github.io/nadia-encode/",
"https://nadia-encode.neocities.org/"
];
//获取更新信息
var timerNum=0,timerId=-2,arrI=0,maxWait=14;
//统计
var statis=document.createElement("iframe");
statis.src=updateArr[0]+"index.html?statis=1";
//储存参数
function setLocal(obj){
	chrome.storage.local.set(obj);
}
//是否为首次安装
try{
chrome.storage.local.get("version",function(res){
	if(!res["version"]||res["version"]!=version) {
		if(!res["version"]){
			setLocal({"runCrx":"1"});
			setLocal({"keyBinds":"112,113"});
		}
		setLocal({"version":version});
		window.open(updateArr[0]+"update.html","_blank");
	}
});
}catch(e){}
//检测开关状态
try{
chrome.storage.local.get("runCrx",function(res){
	if(res["runCrx"]=="-1") {
		runCrx=-1;
		chrome.browserAction.setBadgeText({"text":"×"});
		chrome.browserAction.setBadgeBackgroundColor({"color":"#F00"});
	}
});
}catch(e){}

setLocal({"MainJS":updateArr[0]});
//1、新网页打开后7秒或停用、启用插件后，检测服务器是否宕机
//（无新页面打开和开关插件就停止检测）
setInterval(function(){
	if(isRun||!runCrx) {
		setLocal({"CheckAgain":false});
		return;
	}
	chrome.storage.local.get("CheckAgain",function(res){
		if(res["CheckAgain"]&&!isRun) {
			runOrInit();
		}
	});
},7000);

//检测线路
function runOrInit(init){
	try{
		clearInterval(timerId);
		updateDiv.innerHTML="";
		updatejs.remove();
	}catch(e){}
	maxWait=14;
	setLocal({"CheckAgain":false});
	if(!init) {arrI=0;testUpdate1();}
}

//检测线路和更新
setTimeout(runOrInit,99);

function testUpdate1(){
	console.log(new Date().toTimeString().substr(0,9)+"检测更新");
	isRun=true;
	updatejs=document.createElement("script");
	updatejs.src=updateArr[arrI]+"update.js?t="+new Date().getTime();
	try{
		document.body.appendChild(updatejs);
	}catch(e){}
	timerNum=0;
	timerId=setInterval(testUpdate2,100);
}

function testUpdate2(){
	timerNum++;
	updateStr=updateDiv.innerHTML;
	if(updateStr) {
		cleanUpdate();
	}else if(timerNum>maxWait){
		//2秒如果还没取到更新结果，则网速太慢
		clearInterval(timerId);
		updatejs.remove();
		if(arrI<2){
			arrI++,maxWait+=3;
		}else{
			arrI=0,maxWait=16;
		}
		setTimeout(function(){testUpdate1();},10);
	}
}

function cleanUpdate(){
	chrome.storage.local.set({"MainJS":updateArr[arrI]});
	console.log("选择的服务器："+updateArr[arrI]+"index.html");
	//console.log("timerNum="+timerNum);
	runOrInit(true);
	setTimeout(function(){
		//检测是否有新版本更新
		if(updateStr.length>60) newVersion=true;
		if(runCrx==1) {
			checkNew();
			//统计插件运行情况
			if(arrI==0) {
				document.body.appendChild(statis);
				setTimeout(function(){statis.remove();},499);
			}
		}
		isRun=false;
	},50);
}

return "guziyimai "+version;
}();
