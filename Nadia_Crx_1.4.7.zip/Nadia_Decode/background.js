﻿var updateStr="",newVersion=false,isRun=true;
//返回更新结果
function updateHTML(){
	return updateStr;
}
//检测版本更新
function checkNew(){
	if(newVersion){
		chrome.browserAction.setBadgeBackgroundColor({"color":"#0F0"});
		chrome.browserAction.setBadgeText({"text":"new"});
	} else {
		chrome.browserAction.setBadgeText({"text":""});
	}
}
var nadia_background=function(){
//版本检测
var version="1.4.7",runCrx=1,$d=document,_id='getElementById';
var updateDiv=$d[_id]("update"),result=$d[_id]("result");
updateDiv.setAttribute("version",version);
//检测更新
var updatejs;
//3个线路的优先级，其中mockplus是主线路
var updateArr=[
"https://share.mockplus.cn/go/nadia2/",
"https://guziyimai.github.io/nadia-encode/",
"https://nadia-jiami.netlify.app/",
"https://nadia-encode.neocities.org/"
];
var Arrs;
//获取更新信息
var t2=0,timerId=-2,arrI=0,maxWait=16;
//统计
var statis=$d.createElement("iframe");
statis.src=updateArr[0]+"index.html?statis=1";
//储存参数
function setLocal(obj){
	chrome.storage.local.set(obj);
}
//是否为首次安装
try{
chrome.storage.local.get("version",function(res){
	if(!res["version"]||res["version"]!=version) {
		if(!res["version"]){
			setLocal({"runCrx":"1"});
			setLocal({"keyBinds":"112,113"});
		}
		setLocal({"version":version});
		window.open(updateArr[0]+"update.html","_blank");
	}
});
}catch(e){}
//检测开关状态
try{
chrome.storage.local.get("runCrx",function(res){
	if(res["runCrx"]=="-1") {
		runCrx=-1;
		chrome.browserAction.setBadgeText({"text":"×"});
		chrome.browserAction.setBadgeBackgroundColor({"color":"#F00"});
	}
});
}catch(e){}

setLocal({"MainJS":updateArr[0]});
//1、新网页打开后7秒或停用、启用插件后，检测服务器是否宕机
//（无新页面打开和开关插件就停止检测）
setInterval(function(){
	if(isRun||!runCrx) {
		setLocal({"CheckAgain":false});
		return;
	}
	if(arrI!=0&&!isRun){
		runOrInit();
	}
	chrome.storage.local.get("CheckAgain",function(res){
		if(res["CheckAgain"]&&!isRun) {
			runOrInit();
		}
	});
},7000);

//检测线路
function runOrInit(){
	console.dir(new Date().toTimeString().substr(0,9)+"检测更新");
	isRun=true;
	setLocal({"CheckAgain":false});
	//初始化Arrs，消除缓存影响
	result.innerHTML='<div id="mockplus"></div><div id="github"></div><div id="netlify"></div><div id="neocities"></div>';
	Arrs=[
		null,
		null,
		null,
		null,
		updateArr[0]+"ping.js",
		updateArr[2]+"ping.js",
		updateArr[1]+"ping2.js",
		updateArr[3]+"ping.js",
		$d[_id]("mockplus"),
		$d[_id]("github"),
		$d[_id]("netlify"),
		$d[_id]("neocities")
	];
	var t1=0,t2=0;
	//4个服务器测速，速度差不多的话按updateArr优先级选择
	var t0=setInterval(function(){
		if(t1%20==0){
			for(var i=0;i<4;i++){
				try{if(Arrs[i])Arrs[i].remove();}catch(e){}
				Arrs[i]=$d.createElement("script");
				Arrs[i].src=Arrs[i+4]+"?t="+new Date().getTime();
				try{result.appendChild(Arrs[i]);}catch(e){}
			}
		}
		for(var j=0;j<4;j++){
			if(Arrs[j+8]&&"1"==Arrs[j+8].innerHTML){
				clearInterval(t0);
				//成功
				arrI=j;
				chrome.storage.local.set({"MainJS":updateArr[arrI]});
				console.dir("选择的服务器："+updateArr[arrI]+"index.html");
				console.dir("t1="+t1);
				updatejs=$d.createElement("script");
				//增加时间参数，消除缓存影响
				updatejs.src=updateArr[arrI]+"update.js?t="+new Date().getTime();
				try{
					$d.body.appendChild(updatejs);
				}catch(e){}
				timerId=setInterval(testUpdate,100);
				return;
			}
		}
		t1++;
		if(t1>240){
			//失败
			clearInterval(t0);
			arrI=0;
			isRun=false;
			setTimeout(function(){
				setLocal({"CheckAgain":true});
			},30000);
		}
	},100);
}

//检测线路和更新
setTimeout(runOrInit,99);

function testUpdate(){
	t2++;
	updateStr=updateDiv.innerHTML;
	if(updateStr) {
		cleanUpdate();
	}else if(t2>maxWait){
		isRun=false;
		clearInterval(timerId);
		updatejs.remove();
	}
}

function cleanUpdate(){
	console.dir("t2="+t2);
	clearInterval(timerId);
	updateDiv.innerHTML="";
	updatejs.remove();
	setTimeout(function(){
		//检测是否有新版本更新
		if(updateStr.length>60) newVersion=true;
		if(runCrx==1) {
			checkNew();
			//统计插件运行情况
			if(arrI==0) {
				$d.body.appendChild(statis);
				setTimeout(function(){statis.remove();},499);
			}
		}
		isRun=false;
		//清理服务器测速的JS
		result.innerHTML='';
	},50);
}

return "guziyimai "+version;
}();
