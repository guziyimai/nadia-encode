﻿var updateStr="",newVersion=false,isRun=true;
//返回更新结果
function updateHTML(){
	return updateStr;
}
//检测版本更新
function checkNew(){
	if(newVersion){
		chrome.browserAction.setBadgeBackgroundColor({"color":"#0F0"});
		chrome.browserAction.setBadgeText({"text":"new"});
	} else {
		chrome.browserAction.setBadgeText({"text":""});
	}
}
var nadia_background=function(){
//版本检测
var version="1.4.8",runCrx=1,$d=document,_id='getElementById';
var updateDiv=$d[_id]("update"),result=$d[_id]("result");
updateDiv.setAttribute("version",version);
//检测更新
var updatejs;

//获取更新信息
var t2=0,timerId=-2,maxWait=16;
//储存参数
function setLocal(obj){
	chrome.storage.local.set(obj);
}
//是否为首次安装
try{
chrome.storage.local.get("version",function(res){
	if(!res["version"]||res["version"]!=version) {
		if(!res["version"]){
			setLocal({"runCrx":"1"});
			setLocal({"keyBinds":"112,113"});
		}
		setLocal({"version":version});
		window.open("update.html","_blank");
	}
});
}catch(e){}
//检测开关状态
try{
chrome.storage.local.get("runCrx",function(res){
	if(res["runCrx"]=="-1") {
		runCrx=-1;
		chrome.browserAction.setBadgeText({"text":"×"});
		chrome.browserAction.setBadgeBackgroundColor({"color":"#F00"});
	}
});
}catch(e){}

//设置线路和更新
chrome.storage.local.get("MainJS",function(res){
	if(!res["MainJS"])
		setLocal({"MainJS":"https://nadia-jiami.netlify.app/"});
});	

return "guziyimai "+version;
}();
