﻿var isTest=true;
var nadia_mainfast=function(){
//兽音定时参数
var timerNum,timerId,ipt,rsIpt,notDelay,btn,maxWait,isDiv,errStr="\n【纳迪亚解密插件】调用失败，请尝试手动解密，如果不能解密，则是源密文有误；\n如果手动解密成功，请反馈此BUG：3625270272@qq.com";
/**
 * 获取元素
 * @author guziyimai
 */
function getObj(id,type){
	if(type==1){
		return document.getElementsByTagName(id);
	} else if(type==2){
		return document.getElementsByClassName(id);
	} else {
		return document.getElementById(id);
	}
}

//定义变量
var isPowerUrl=false;
var version="1.4.8";
var NadiaTQM=document.createElement("NadiaTQM");
var mainjs=document.createElement("script");
var runCrx="2",keyBinds="-1";

//从storage取版本号的值
document.body.appendChild(NadiaTQM);
chrome.storage.local.get("version",function(res){
	try{version=res["version"];}catch(e){}
	//注入提取码存储元素
	NadiaTQM.setAttribute("version",version);
	
	try{
		isPowerUrl=getObj("Z3V6aXlpbWFp",2).length==5;
		//向官网注入NadiaCrx标记，而不是JS
		if(isPowerUrl){
			//需要注入
			var NadiaCrx=getObj('NadiaCrx',1);
			if(NadiaCrx && NadiaCrx[0]) {
				NadiaCrx[0].innerHTML="KnXNNnV3wp";
			}
			var NadiaVer=getObj('nadia_decode');
			if(NadiaVer){
				NadiaVer.innerHTML="纳迪亚文本解密v.last";
				NadiaVer.parentElement.title="版本号：last";
			}
			//return "guziyimai "+version;
		}
	}catch(e){}

});


var runUrl=top.location.href,mcBtn,mcTxt,timerId2,timerNum2;

//获取运行开关
function getSet(){
	try{
		//是否运行
		chrome.storage.local.get("runCrx",function(res){
			try{
				if(res["runCrx"]&&runCrx!=res["runCrx"]){
					runCrx=res["runCrx"];
					NadiaTQM.setAttribute("runCrx",runCrx);
					if(runCrx=="1") {
						console.dir("启用：纳迪亚解密"+version);
					} else {
						console.dir("停用：纳迪亚解密"+version);
					}
					document.getSelection().empty();
					getObj("nadia_menu").style.display="none";
					getObj("kill_tieba_ad",2)[0].click();
				}
			}catch(e){}
		});
		//绑定按键
		chrome.storage.local.get("keyBinds",function(res){
			try{
				if(res["keyBinds"]&&keyBinds!=res["keyBinds"]){
					keyBinds=res["keyBinds"];
					NadiaTQM.setAttribute("keyBinds",keyBinds);
					document.getSelection().empty();
					getObj("nadia_menu").style.display="none";
				}
			}catch(e){}	
		});
	}catch(e){}
}
try{getSet();chrome.storage.onChanged.addListener(getSet);}catch(e){}
NadiaTQM.onclick=function(e){
	var key=NadiaTQM.getAttribute("key");
	var obj={};obj[key]=NadiaTQM.getAttribute("tqm");
	try{
		chrome.storage.local.set(obj,function(){
			NadiaTQM.removeAttribute("key");
			NadiaTQM.removeAttribute("tqm");
			//是否为兽音传参？
			if(key&&key.substr(0,4)=="http"){
				timerNum=0;
				timerId=setInterval(function(){
					timerNum++;
					try{
						chrome.storage.local.get("return-roar",function(res){
							if(res["return-roar"]) {
								clearInterval(timerId);
								chrome.storage.local.remove("return-roar");
								NadiaTQM.setAttribute("return-roar",res["return-roar"]);
							} else if(timerNum>60){
								clearInterval(timerId);
							}
						});
					} catch(e) {}
				},150);
			}
		});
	}catch(e){}
	e.stopPropagation();
}

setTimeout(function(){
	if(!isTest){
		try{
			var str=getObj("NadiaCrx_guziyimai").getAttribute("data");
			if(isPowerUrl||str=="jsIsRun"){
				//自毁代码
				setTimeout(function(){mainjs.remove();},200);
			}
		}catch(e){}
	}else{
		setTimeout(function(){mainjs.remove();},200);
	}
},1600);

/**
 * 给SB的IE用的！！！
 * @author guziyimai
 */
try{
	"".replaceAll("");
}catch(err){
	String.prototype.replaceAll=function(a,b){
		return this.split(a).join(b);
	};
	Array.prototype.indexOf=function(elt,start){
		var len=this.length;
		if(!start) start=0;
		for(;start<len;start++)
			if(this[start] == elt) return start;
		return -1;
	};
}

return "guziyimai "+version;
}();