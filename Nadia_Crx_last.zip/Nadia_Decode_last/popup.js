﻿var nadia_popup=function(){
var atags=document.getElementsByTagName('a'),base="https://";
var urls=[
base+"nadia-jiami.netlify.app",
base+"guziyimai.github.io/nadia-encode",
"update.html",
"mailto:3625270272@qq.com",
base+"gitee.com/guziyimai/encryption",
base+"github.com/guziyimai/nadia-encode"
];

//onclick不能写for循环，懒得研究bug出在哪了？
atags[0].onclick=function(){window.open(urls[0],"_blank");};
atags[1].onclick=function(){window.open(urls[1],"_blank");};
atags[2].onclick=function(){window.open(urls[2],"_blank");};
atags[3].onclick=function(){window.open(urls[3],"_blank");};
atags[4].onclick=function(){window.open(urls[4],"_blank");};
atags[5].onclick=function(){window.open(urls[5],"_blank");};

//启用、停用插件
var runCrx=document.getElementsByClassName('runCrx')[0],lock=false,isRun=true;
//从storage取版本号的值
var version="1.3";
var keySel=document.getElementsByClassName('keySet'),selStr="<option value='0'>---</option>",mySet=document.getElementById('mySet'),setDiv=document.getElementById('setDiv');
mySet.onclick=function(){
	if(mySet.innerHTML=="设置&gt;&nbsp;") {
		mySet.innerHTML="设置∨&nbsp;";
		setDiv.style.display="block";
	}else{
		mySet.innerHTML="设置&gt;&nbsp;";
		setDiv.style.display="none";
	}
}
function keySet(){
	var other=this==keySel[0]?keySel[1]:keySel[0];
	if(this.value!=0&&this.value==other.value) {
		other.value=0;
	}
	var obj={};obj["keyBinds"]=keySel[0].value+","+keySel[1].value;
	chrome.storage.local.set(obj);
}
chrome.storage.local.get("version",function(res){
	try{version=res["version"];}catch(e){}
	//初始化按键绑定
	for(var i=1;i<13;i++){
		selStr+="<option value='"+(111+i)+"'>F"+i+"</option>";
	}
	keySel[0].innerHTML=selStr;
	keySel[1].innerHTML=selStr;
	keySel[0].onchange=keySet;
	keySel[1].onchange=keySet;
	chrome.storage.local.get("keyBinds",function(res){
		if(res["keyBinds"]) {
			var keyBinds=res["keyBinds"].split(",");
			keySel[0].value=keyBinds[0];
			keySel[1].value=keyBinds[1];
		}
	});
	//启用停用click事件
	runCrx.onclick=function(){
		if(lock) return;
		setTimeout(function(){lock=false;},199);
		lock=true;
		if(!isRun) {
			isRun=true;
			chrome.storage.local.set({"runCrx":"1"},function(){
				runCrx.innerHTML="已启用v.last";
				runCrx.title="单击以停用插件";
				runCrx.className="runCrx";
				chrome.browserAction.setBadgeText({"text":""});
				chrome.runtime.getBackgroundPage(function(bg){
					bg.checkNew();
				});
				chrome.storage.local.set({"CheckAgain":true});
			});
		} else {
			isRun=false;
			chrome.storage.local.set({"runCrx":"-1"},function(){
				runCrx.innerHTML="已停用v.last";
				runCrx.title="单击以启用插件";
				runCrx.className="stopCrx";
				chrome.browserAction.setBadgeText({"text":"×"});
				chrome.browserAction.setBadgeBackgroundColor({"color":"#F00"});
			});
		}
	}
	//查询是否已停用
	chrome.storage.local.get("runCrx",function(res){
		if(res["runCrx"]=="-1") {
			isRun=false;
			runCrx.innerHTML="已停用v.last";
			runCrx.title="单击以启用插件";
			runCrx.className="stopCrx";
		} else {
			runCrx.innerHTML="已启用v.last";
		}
	});

});

return "guziyimai "+version;
}();